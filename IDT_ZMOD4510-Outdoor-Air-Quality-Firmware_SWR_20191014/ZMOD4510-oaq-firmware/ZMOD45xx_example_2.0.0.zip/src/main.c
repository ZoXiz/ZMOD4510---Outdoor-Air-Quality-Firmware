/*******************************************************************************
 * Copyright (c) 2019 Integrated Device Technology, Inc.
 * All Rights Reserved.
 *
 * This code is proprietary to IDT, and is license pursuant to the terms and
 * conditions that may be accessed at:
 * https://www.idt.com/document/msc/idt-software-license-terms-gas-sensor-software
 *
 ******************************************************************************/

/**
 * @file    main.c
 * @brief   This is an example for the ZMOD4510 gas sensor module.
 * @version 2.0.0
 * @date    2019-09-25
 * @author  IDT
 **/

#include "main.h"

/* forward declaration */
void print_hicom_error(hicom_status_t status);

int main()
{
    /* These are the hardware handles which needs to be adjusted to specific HW */
    hicom_handle_t hicom_handle;
    hicom_status_t hicom_status;

    zmod45xx_dev_t dev;
    int8_t ret;
    uint8_t i;
    uint8_t stabilization_samples = 0;
    uint8_t zmod45xx_status = 0;
    uint8_t adc_result[30] = { 0 };
    float rmox[15] = { 0 };
    float aqi;
    oaq_base_handle_t handle;

    /* ****** BEGIN TARGET SPECIFIC INITIALIZATION ************************** */
    /* This part automatically resets the sensor. */
    /* connect to HiCom board */
    hicom_status = hicom_open(&hicom_handle);
    if (FTC_SUCCESS != hicom_status) {
        print_hicom_error(hicom_status);
        return hicom_status;
    }

    /* switch supply on */
    hicom_status = hicom_power_on(hicom_handle);
    if (FTC_SUCCESS != hicom_status) {
        print_hicom_error(hicom_status);
        return hicom_status;
    }

    set_hicom_handle(&hicom_handle);

    /* ****** END TARGET SPECIFIC INITIALIZATION **************************** */

    /* Set initial hardware parameter */
    dev.read = hicom_i2c_read;
    dev.write = hicom_i2c_write;
    dev.delay_ms = hicom_sleep;
    dev.i2c_addr = ZMOD4510_I2C_ADDRESS;

    /* initialize and start sensor */
    ret = zmod45xx_read_sensor_info(&dev);
    if (ret) {
        printf("Error %d, exiting program!\n", ret);
        goto exit;
    }

    ret = zmod45xx_init_sensor(&dev);
    if (ret) {
        printf("Error %d, exiting program!\n", ret);
        goto exit;
    }

    ret = zmod45xx_init_measurement(&dev);
    if (ret) {
        printf("Error %d, exiting program!\n", ret);
        goto exit;
    }

    ret = zmod45xx_start_measurement(&dev);
    if (ret) {
        printf("Error %d, exiting program!\n", ret);
        goto exit;
    }

    /* One time initialization of the algorithm */
    oaq_base_init(&handle, dev.general_purpose, STABILIZATION_SAMPLES);

    printf("Evaluate measurements in a loop. Press any key to quit.\n");
    do {
        /* INSTEAD OF POLLING THE INTERRUPT CAN BE USED FOR OTHER HW */
        /* wait until readout result is possible */

        ret = zmod45xx_read_status(&dev, &zmod45xx_status);
        if (ret) {
            printf("Error %d, exiting program!\n", ret);
            goto exit;
        }
        if (STATUS_SEQUENCER_RUNNING_MASK & zmod45xx_status) {
            dev.delay_ms(50);
            continue;
        }

        ret = zmod45xx_read_adc_results(&dev, adc_result);
        if (ret) {
            printf("Error %d, exiting program!\n", ret);
            goto exit;
        }

        /* start a new measurement before result calculation */
        ret = zmod45xx_start_measurement(&dev);
        if (ret) {
            printf("Error %d, exiting program!\n", ret);
            goto exit;
        }

        ret = zmod45xx_calc_rmox(&dev, adc_result, rmox);
        if (ret) {
            printf("Error %d, exiting program!\n", ret);
            goto exit;
        }
        /* To work with the algorithms target specific libraries needs to be
         * downloaded from IDT webpage and included into the project */

        /* calculate the outdoor air quality index */
        aqi = calc_oaq(&handle, rmox, RCDA_STRATEGY_ADJ,
                       GAS_DETECTION_STRATEGY_AUTO, D_RISING_M1, D_FALLING_M1,
                       D_CLASS_M1);

        printf("\n");
        printf("Measurement:\n");
        printf("  R_mox results:\n");
        for (i = 0; i < 15; i++) {
            printf("  R_mox[%02d] = %8.0f Ohm\n", i, rmox[i]);
        }
        if (STABILIZATION_SAMPLES > stabilization_samples) {
            stabilization_samples++;
            printf("Sensor is stabilizing.\n");
        }

        printf("  AQI %f\n", aqi);

        /* kbhit() is a windows specific function and needs to be removed for
         * other hardware. */
    } while (!kbhit());

exit:
    /* ****** BEGIN TARGET SPECIFIC DEINITIALIZATION ****** */
    hicom_status = hicom_power_off(hicom_handle);
    if (FTC_SUCCESS != hicom_status) {
        print_hicom_error(hicom_status);
        return hicom_status;
    }

    /* disconnect HiCom board */
    hicom_status = hicom_close(hicom_handle);
    if (FTC_SUCCESS != hicom_status) {
        print_hicom_error(hicom_status);
        return hicom_status;
    }
    /* ****** END TARGET SPECIFIC DEINITIALIZATION ****** */

    printf("Bye!\n");
    return 0;
}

void print_hicom_error(hicom_status_t status)
{
    char error_str[512];
    hicom_get_error_string(status, error_str, sizeof error_str);
    fprintf(stderr, "ERROR (HiCom): %s\n", error_str);
}
