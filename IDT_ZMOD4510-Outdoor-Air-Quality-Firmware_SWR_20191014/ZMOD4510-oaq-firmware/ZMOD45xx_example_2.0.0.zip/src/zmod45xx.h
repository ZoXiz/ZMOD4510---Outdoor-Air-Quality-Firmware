/*******************************************************************************
 * Copyright (c) 2019 Integrated Device Technology, Inc.
 * All Rights Reserved.
 *
 * This code is proprietary to IDT, and is license pursuant to the terms and
 * conditions that may be accessed at:
 * https://www.idt.com/document/msc/idt-software-license-terms-gas-sensor-software
 *
 ******************************************************************************/

/**
 * @file    zmod45xx.h
 * @brief   ZMOD45xx functions
 * @version 2.0.0
 * @date    2019-10-02
 * @author  IDT
 */

#ifndef _ZMOD45XX_H
#define _ZMOD45XX_H

#ifdef __cplusplus
extern "C" {
#endif

#include "zmod45xx_types.h"

#define ZMOD4510_I2C_ADDRESS (0x33)

#define ZMOD45XX_ADDR_PID             (0x00)
#define ZMOD45XX_ADDR_CONF            (0x20)
#define ZMOD45XX_ADDR_GENERAL_PURPOSE (0x26)
#define ZMOD45XX_ADDR_CMD             (0x93)
#define ZMOD45XX_ADDR_STATUS          (0x94)
#define ZMOD45XX_ADDR_TRACKING        (0x3A)

#define ZMOD45XX_LEN_PID             (2)
#define ZMOD45XX_LEN_CONF            (6)
#define ZMOD45XX_LEN_TRACKING        (6)
#define ZMOD45XX_LEN_GENERAL_PURPOSE (9)

#define STATUS_SEQUENCER_RUNNING_MASK   (0x80) /**< Sequencer is running */
#define STATUS_SLEEP_TIMER_ENABLED_MASK (0x40) /**< SleepTimer_enabled */
#define STATUS_ALARM_MASK               (0x20) /**< Alarm */
#define STATUS_LAST_SEQ_STEP_MASK       (0x1F) /**< Last executed sequencer step */
#define STATUS_POR_EVENT_MASK           (0x80) /**< POR_event */
#define STATUS_ACCESS_CONFLICT_MASK     (0x40) /**< AccessConflict */

/**
 * @brief   Read sensor parameter.
 * @param   [in] dev pointer to the device
 * @return  error code
 * @retval  0 success
 * @retval  "!= 0" error
 * @note    This function must be called once before running other sensor
 *          functions.
 */
int8_t zmod45xx_read_sensor_info(zmod45xx_dev_t *dev);

/**
 * @brief   Initialize the sensor after power on.
 * @param   [in] dev pointer to the device
 * @return  error code
 * @retval  0 success
 * @retval  "!= 0" error
 */
int8_t zmod45xx_init_sensor(zmod45xx_dev_t *dev);

/**
 * @brief   Initialize the sensor for zmod4510 measurement.
 * @param   [in] dev pointer to the device
 * @return  error code
 * @retval  0 success
 * @retval  "!= 0" error
 */
int8_t zmod45xx_init_measurement(zmod45xx_dev_t *dev);

/**
 * @brief   Start the measurement.
 * @param   [in] dev pointer to the device
 * @return  error code
 * @retval  0 success
 * @retval  "!= 0" error
 */
int8_t zmod45xx_start_measurement(zmod45xx_dev_t *dev);

/**
 * @brief   Read the status of the device.
 * @param   [in] dev pointer to the device
 * @param   [in,out] status pointer to the status variable
 * @return  error code
 * @retval  0 success
 * @retval  "!= 0" error
 */
int8_t zmod45xx_read_status(zmod45xx_dev_t *dev, uint8_t *status);

/**
 * @brief   Read adc values from the sensor
 * @param   [in] dev pointer to the device
 * @param   [in,out] adc_result pointer to the adc results
 * @return  error code
 * @retval  0 success
 * @retval  "!= 0" error
 */
int8_t zmod45xx_read_adc_results(zmod45xx_dev_t *dev, uint8_t *adc_result);

/**
 * @brief   Calculate mox resistance
 * @param   [in] dev pointer to the device
 * @param   [in,out] adc_result pointer to the adc results
 * @param   [in,out] rmox pointer to the rmox values
 * @return  error code
 * @retval  0 success
 * @retval  "!= 0" error
 */
int8_t zmod45xx_calc_rmox(zmod45xx_dev_t *dev, uint8_t *adc_result,
                          float *rmox);

#ifdef __cplusplus
}
#endif

#endif //  _ZMOD45XX_H
