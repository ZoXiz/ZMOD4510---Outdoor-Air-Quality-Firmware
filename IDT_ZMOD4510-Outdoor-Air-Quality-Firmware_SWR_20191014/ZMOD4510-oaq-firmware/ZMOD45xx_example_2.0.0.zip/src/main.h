/*******************************************************************************
 * Copyright (c) 2019 Integrated Device Technology, Inc.
 * All Rights Reserved.
 *
 * This code is proprietary to IDT, and is license pursuant to the terms and
 * conditions that may be accessed at:
 * https://www.idt.com/document/msc/idt-software-license-terms-gas-sensor-software
 *
 ******************************************************************************/

/**
 * @file    main.h
 * @brief   This is an example for the ZMOD4510 gas sensor module.
 * @version 2.0.0
 * @date    2019-09-25
 * @author  IDT
 */

/* This include is just for Windows PCs. */
#include <conio.h>

/* Algorithm library header files, download the target specific library
 * from the IDT webpage. */
#include "oaq.h"

/* Files needed for hardware access, needs to be adjusted to target. */
#include "hicom.h"
#include "hicom_i2c.h"

/* files to control the sensor */
#include "zmod45xx.h"

#define D_RISING_M1  4.9601944386079566e-05
#define D_FALLING_M1 0.3934693402873666
#define D_CLASS_M1   0.024690087971667385

#define STABILIZATION_SAMPLES 10
