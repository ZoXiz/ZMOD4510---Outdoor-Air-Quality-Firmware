/*******************************************************************************
 * Copyright (c) 2019 Integrated Device Technology, Inc.
 * All Rights Reserved.
 *
 * This code is proprietary to IDT, and is license pursuant to the terms and
 * conditions that may be accessed at:
 * https://www.idt.com/document/msc/idt-software-license-terms-gas-sensor-software
 *
 ******************************************************************************/

/**
 * @file    zmod45xx.c
 * @brief   ZMOD45xx functions
 * @version 2.0.0
 * @date    2019-10-02
 * @author  IDT
 */

#include "zmod45xx.h"
#include "zmod45xx_config.h"


int8_t zmod45xx_read_sensor_info(zmod45xx_dev_t *dev)
{
    int8_t ret = 0;
    uint8_t data[ZMOD45XX_LEN_PID];
    uint8_t status = 0;
    uint8_t cmd = 0;
    uint16_t i = 0;

    /* wait for sensor ready */
    do {
        ret = dev->write(dev->i2c_addr, ZMOD45XX_ADDR_CMD, &cmd, 1);
        if (ret) {
            return ERROR_I2C;
        }

        dev->delay_ms(200);

        ret = zmod45xx_read_status(dev, &status);
        if (ret) {
            return ret;
        }
        i++;
    } while ((0x00 != (status & 0x80)) && (i < 1000));

    if (1000 <= i) {
        return ERROR_GAS_TIMEOUT;
    }

    ret = dev->read(dev->i2c_addr, ZMOD45XX_ADDR_PID, data, ZMOD45XX_LEN_PID);
    if (ret) {
        return ERROR_I2C;
    }
    dev->pid = data[0] << 8 | data[1];

    ret = dev->read(dev->i2c_addr, ZMOD45XX_ADDR_GENERAL_PURPOSE,
                    dev->general_purpose, ZMOD45XX_LEN_GENERAL_PURPOSE);
    if (ret) {
        return ERROR_I2C;
    }

    ret = dev->read(dev->i2c_addr, ZMOD45XX_ADDR_CONF, dev->config,
                    ZMOD45XX_LEN_CONF);
    if (ret) {
        return ERROR_I2C;
    }

    switch (dev->pid) {
    case ZMOD4510_PID: {
        dev->meas_conf = &zmod4510;
        dev->init_conf = &zmod45xxi;
    } break;

    default: {
        return ERROR_SENSOR_UNSUPPORTED;
    } break;
    }

    return ZMOD45XX_OK;
}

int8_t zmod45xx_calc_factor(zmod45xx_dev_t *dev, float factor, uint8_t *data)
{
    float hspf;

    hspf = (-((float)dev->config[2] * 256.0 + dev->config[3]) *
            ((dev->config[4] + 640.0) * (dev->config[5] + factor) - 512000.0)) /
           12288000.0;
    if ((0.0 > hspf) || (4096.0 < hspf)) {
        return ERROR_INIT_OUT_OF_RANGE;
    }
    *data = (uint8_t)((uint16_t)hspf >> 8);
    *(data + 1) = (uint8_t)((uint16_t)hspf & 0x00FF);

    return ZMOD45XX_OK;
}

int8_t zmod45xx_init_sensor(zmod45xx_dev_t *dev)
{
    int8_t ret = 0;
    uint8_t data[4] = { 0 };
    uint8_t zmod44xx_status;

    if (!dev->init_conf) {
        return ERROR_CONFIG_MISSING;
    }

    ret = dev->read(dev->i2c_addr, 0xB7, data, 1);
    if (ret) {
        return ERROR_I2C;
    }

    ret = zmod45xx_calc_factor(dev, 80, data);
    if (ret) {
        return ret;
    }

    ret = dev->write(dev->i2c_addr, dev->init_conf->h.addr, data,
                     dev->init_conf->h.len);
    if (ret) {
        return ERROR_I2C;
    }

    ret = dev->write(dev->i2c_addr, dev->init_conf->d.addr,
                     dev->init_conf->d.data, dev->init_conf->d.len);
    if (ret) {
        return ERROR_I2C;
    }

    ret = dev->write(dev->i2c_addr, dev->init_conf->m.addr,
                     dev->init_conf->m.data, dev->init_conf->m.len);
    if (ret) {
        return ERROR_I2C;
    }

    ret = dev->write(dev->i2c_addr, dev->init_conf->s.addr,
                     dev->init_conf->s.data, dev->init_conf->s.len);
    if (ret) {
        return ERROR_I2C;
    }

    ret =
        dev->write(dev->i2c_addr, ZMOD45XX_ADDR_CMD, &dev->init_conf->start, 1);
    if (ret) {
        return ERROR_I2C;
    }

    do {
        ret = zmod45xx_read_status(dev, &zmod44xx_status);
        if (ret) {
            printf("Error %d, exiting program!\n", ret);
            return ret;
        }
        dev->delay_ms(50);
    } while (zmod44xx_status & STATUS_SEQUENCER_RUNNING_MASK);

    ret = dev->read(dev->i2c_addr, dev->init_conf->r.addr, data,
                    dev->init_conf->r.len);
    if (ret) {
        return ERROR_I2C;
    }

    dev->mox_lr = (uint16_t)(data[0] << 8) | data[1];
    dev->mox_er = (uint16_t)(data[2] << 8) | data[3];

    ret = dev->read(dev->i2c_addr, 0xB7, data, 1);
    if (ret) {
        return ERROR_I2C;
    }
    if (0 != data[0]) {
        if (STATUS_ACCESS_CONFLICT_MASK & data[0]) {
            return ERROR_ACCESS_CONFLICT;
        } else if (STATUS_POR_EVENT_MASK & data[0]) {
            return ERROR_POR_EVENT;
        }
    }

    return ZMOD45XX_OK;
}

int8_t zmod45xx_init_measurement(zmod45xx_dev_t *dev)
{
    int8_t ret = 0;
    uint8_t data[10] = { 0 };

    if (!dev->meas_conf) {
        return ERROR_CONFIG_MISSING;
    }

    ret = dev->read(dev->i2c_addr, 0xB7, data, 1);
    if (ret) {
        return ERROR_I2C;
    }

    ret = zmod45xx_calc_factor(dev, -440, data);
    if (ret) {
        return ret;
    }

    ret = zmod45xx_calc_factor(dev, -490, data + 2);
    if (ret) {
        return ret;
    }

    ret = zmod45xx_calc_factor(dev, -540, data + 4);
    if (ret) {
        return ret;
    }

    ret = zmod45xx_calc_factor(dev, -590, data + 6);
    if (ret) {
        return ret;
    }

    ret = zmod45xx_calc_factor(dev, -640, data + 8);
    if (ret) {
        return ret;
    }

    ret = dev->write(dev->i2c_addr, dev->meas_conf->h.addr, data,
                     dev->meas_conf->h.len);
    if (ret) {
        return ERROR_I2C;
    }

    ret = dev->write(dev->i2c_addr, dev->meas_conf->d.addr,
                     dev->meas_conf->d.data, dev->meas_conf->d.len);
    if (ret) {
        return ERROR_I2C;
    }

    ret = dev->write(dev->i2c_addr, dev->meas_conf->m.addr,
                     dev->meas_conf->m.data, dev->meas_conf->m.len);
    if (ret) {
        return ERROR_I2C;
    }

    ret = dev->write(dev->i2c_addr, dev->meas_conf->s.addr,
                     dev->meas_conf->s.data, dev->meas_conf->s.len);
    if (ret) {
        return ERROR_I2C;
    }

    return ZMOD45XX_OK;
}

int8_t zmod45xx_start_measurement(zmod45xx_dev_t *dev)
{
    int8_t ret = 0;

    ret =
        dev->write(dev->i2c_addr, ZMOD45XX_ADDR_CMD, &dev->meas_conf->start, 1);
    if (ret) {
        return ERROR_I2C;
    }
    return ZMOD45XX_OK;
}

int8_t zmod45xx_read_status(zmod45xx_dev_t *dev, uint8_t *status)
{
    int8_t ret;
    uint8_t st;

    ret = dev->read(dev->i2c_addr, ZMOD45XX_ADDR_STATUS, &st, 1);
    if (0 != ret) {
        return ret;
    }
    *status = st;
    return ZMOD45XX_OK;
}

int8_t zmod45xx_read_adc_results(zmod45xx_dev_t *dev, uint8_t *adc_result)
{
    int8_t ret = 0;
    uint8_t data[2] = { 0 };

    ret = dev->read(dev->i2c_addr, dev->meas_conf->r.addr, adc_result,
                    dev->meas_conf->r.len);
    if (ret) {
        return ERROR_I2C;
    }

    ret = dev->read(dev->i2c_addr, 0xB7, data, 1);
    if (ret) {
        return ERROR_I2C;
    }

    if (0 != data[0]) {
        if (STATUS_ACCESS_CONFLICT_MASK & data[0]) {
            return ERROR_ACCESS_CONFLICT;
        } else if (STATUS_POR_EVENT_MASK & data[0]) {
            return ERROR_POR_EVENT;
        }
    }

    return ZMOD45XX_OK;
}

int8_t zmod45xx_calc_rmox(zmod45xx_dev_t *dev, uint8_t *adc_result, float *rmox)
{
    uint8_t i;
    uint16_t adc_value = 0;
    float *p = rmox;
    float rmox_local = 0;

    for (i = 0; i < dev->meas_conf->r.len; i += 2) {
        adc_value = (uint16_t)(*(adc_result + i) << 8) | *(adc_result + i + 1);
        if (0.0 >= (adc_value - dev->mox_lr)) {
            rmox_local = 1e-3;
        } else if (0.0 >= (dev->mox_er - adc_value)) {
            rmox_local = 1e12;
        } else {
            rmox_local = dev->config[0] * 1e3 * (adc_value - dev->mox_lr) /
                         (dev->mox_er - adc_value);
        }

        if (1e12 < rmox_local) {
            rmox_local = 1e12;
        }

        *p = rmox_local;
        p++;
    }

    return ZMOD45XX_OK;
}
