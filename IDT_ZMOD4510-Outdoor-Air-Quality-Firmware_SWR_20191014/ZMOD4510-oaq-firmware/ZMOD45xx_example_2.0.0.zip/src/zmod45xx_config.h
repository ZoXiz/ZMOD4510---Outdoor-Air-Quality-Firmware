/*******************************************************************************
 * Copyright (c) 2019 Integrated Device Technology, Inc.
 * All Rights Reserved.
 *
 * This code is proprietary to IDT, and is license pursuant to the terms and
 * conditions that may be accessed at:
 * https://www.idt.com/document/msc/idt-software-license-terms-gas-sensor-software
 *
 ******************************************************************************/

/**
 * @file    zmod45xx_config.h
 * @brief   ZMOD45xx configuration
 * @version 2.0.0
 * @date    2019-07-18
 * @author  IDT
 */

#ifndef _ZMOD45XX_CONFIG_H
#define _ZMOD45XX_CONFIG_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

#include "zmod45xx_types.h"

/* ZMOD4510 measurement configuration */
const uint8_t data_set_4510[] = { 0x20, 0x05, 0xA0, 0x18, 0xC0, 0x1C,
                                  0x03,
                                  0x00, 0x00, 0x00, 0x08, 0x00, 0x10, 0x00,
                                  0x01, 0x00, 0x09, 0x00, 0x11, 0x00, 0x02,
                                  0x00, 0x0A, 0x00, 0x12, 0x00, 0x03, 0x00,
                                  0x0B, 0x00, 0x13, 0x00, 0x04, 0x00, 0x0C,
                                  0x80, 0x14 };

/* ZMOD4510 initialization configuration */
const uint8_t data_set_4510i[] = { 0x00, 0xA4, 0xC3, 0xE3,
                                   0x00, 0x00, 0x80, 0x40 };

/**
 * @brief ZMOD4510 configuration
 */
const zmod45xx_conf zmod4510 = {
    .start = 0x80,
    .h = { .addr = 0x40, .len = 10 },
    .d = { .addr = 0x50, .len = 6, .data = &data_set_4510[0] },
    .m = { .addr = 0x60, .len = 1, .data = &data_set_4510[6] },
    .s = { .addr = 0x68, .len = 30, .data = &data_set_4510[7] },
    .r = { .addr = 0x97, .len = 30 }

};

/**
 * @brief ZMOD45XX sensor initialization configuration
 */
const zmod45xx_conf zmod45xxi = {
    .start = 0x80,
    .h = { .addr = 0x40, .len = 2 },
    .d = { .addr = 0x50, .len = 2, .data = &data_set_4510i[0] },
    .m = { .addr = 0x60, .len = 2, .data = &data_set_4510i[2] },
    .s = { .addr = 0x68, .len = 4, .data = &data_set_4510i[4] },
    .r = { .addr = 0x97, .len = 4 }

};

#ifdef __cplusplus
}
#endif

#endif //  _ZMOD45XX_CONFIG_H
