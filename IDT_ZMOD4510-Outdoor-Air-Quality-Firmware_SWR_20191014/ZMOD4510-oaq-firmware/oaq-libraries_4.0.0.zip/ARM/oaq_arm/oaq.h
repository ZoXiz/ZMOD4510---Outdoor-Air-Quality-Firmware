/*******************************************************************************
 * Copyright (c) 2019 Integrated Device Technology, Inc.
 * All Rights Reserved.
 *
 * This code is proprietary to IDT, and is license pursuant to the terms and
 * conditions that may be accessed at:
 * https://www.idt.com/document/msc/idt-software-license-terms-gas-sensor-software
 *
 ******************************************************************************/

/**
  * @file    oaq.h
  * @date    2019-09-24
 * @author  IDT
  * @version 4.0.0 - https://semver.org/
  * @brief   This file contains the data structure definitions and
  *          the function definitions for the OAQ base algorithm.
  * @details The library contains an algorithm to calculate an OAQ index from
  *          ZMOD4510 measurements. The implementation is made to allow more than one
  *          sensor.
  *
  */

#ifndef OAQ_H_
#define OAQ_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <math.h>

/** @defgroup zmod4510_handles Handles of the Rcda
    @brief Handles of the Rcda
  * @{
  */

#define RCDA_STRATEGY_FIX (0) /*!< hold rcda fixed */
#define RCDA_STRATEGY_SET (1) /*!< set the rcda to the actal measurement */
#define RCDA_STRATEGY_ADJ (2) /*!< adjust rcda to follow slow drifts */

/**
  * @}
  */

/** @defgroup zmod4510_discriminations Discriminations of the gases
    @brief Discriminations of the gases
  * @{
  */

#define GAS_DETECTION_STRATEGY_AUTO (0) /*!< use automatic gas discrimination */
#define GAS_DETECTION_STRATEGY_FORCEO3 (1) /*!< handle the measurements as O3 */
#define GAS_DETECTION_STRATEGY_FORCENO2                                        \
    (2) /*!< handle the measurements as NO2 */

/**
* @brief internal precision for gas classification, must be at least 32bit floating point!
*/
typedef float oaq_prec_t;

/**
* @brief Variables that describe the sensor or the algorithm state.
*/
typedef struct {
    float trim_beta2; /**< slope from trim data */
    float trim_b; /**< NO2 intercept from trim data */
    float rcda_22; /**< Rcda estimation for Rmox_22 */
    float rcda_42; /**< Rcda estimation for Rmox_42 */
    uint8_t trim_data_version; /**< version of trim data in NVM */
    uint8_t
        stabilization_sample; /**< number of samples still needed for stabilization */
    float prob_no2; /**< NO2 probability */
    float conc_no2; /**< equivalent NO2 concentration [ppb] */
    float conc_o3; /**< equivalent O3 concentration [ppb] */
    float aqi_no2; /**< equivalent NO2 AQI */
    float aqi_o3; /**< equivalent O3 AQI */
} oaq_base_handle_t;

/**
 * @brief   initializes the OAQ algorithm
 * @param   [out] handle pointer to algorithm state variable
 * @param   [in] general_purpose pointer to the 9 bytes trim information
 * @param   [in] stabilization_samples number of samples to be ignored for stabilization
*/
void oaq_base_init(oaq_base_handle_t *handle, const uint8_t *general_purpose,
                   const uint8_t stabilization_samples);

/**
 * @brief   calculates AQI from present sample
 * @param   [in] handle pointer to algorithm state variable 
 * @param   [in] rmox pointer to array of the 15 sequencer rmox measurements
 * @param   [in] rcda_strategy how to handle Rcda
 * @param   [in] gas_detection_strategy do automatic gas discrimination or force O3 or NO2
 * @param   [in] d_rising_m1 rcda damping factor for rising rmox
 * @param   [in] d_falling_m1 rcda damping factor for falling rmox
 * @param   [in] d_class_m1 damping factor for gas classification
 * @return  AQI value
 */
float calc_oaq(oaq_base_handle_t *handle, const float *rmox,
               const uint8_t rcda_strategy,
               const uint8_t gas_detection_strategy, const float d_rising_m1,
               const float d_falling_m1, const float d_class_m1);

#ifdef __cplusplus
}
#endif

#endif /* OAQ_H_ */
